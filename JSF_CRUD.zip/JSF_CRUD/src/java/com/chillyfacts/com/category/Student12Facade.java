/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chillyfacts.com.category;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author aayush jha
 */
@Stateless
public class Student12Facade extends AbstractFacade<Student12> {

    @PersistenceContext(unitName = "JSF_CRUDPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public Student12Facade() {
        super(Student12.class);
    }
    
}
