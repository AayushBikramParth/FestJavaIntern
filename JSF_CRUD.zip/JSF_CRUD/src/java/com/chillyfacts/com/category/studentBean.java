/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.chillyfacts.com.category;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.ManagedBean;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.faces.bean.ViewScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author aayush jha
 */
@ManagedBean(name="studentBean")
@Named(value = "studentBean")
@ViewScoped
@Dependent
public class studentBean implements Serializable {
    private String name;
    private String address;
    private String selectedClass;
    private List<String> selectedSubjects;
    private List<String> classList;
    private List<String> subjectList;
    
    @PersistenceContext(unitName = "myPU")
    private EntityManager em;
    @PostConstruct
   public void init() {
        classList = new ArrayList<>();
        classList.add("Class 1");
        classList.add("Class 2");
        classList.add("Class 3");
        
        subjectList = new ArrayList<>();
        subjectList.add("Maths");
        subjectList.add("Science");
        subjectList.add("English");
        
   }
   public void updateSubjects() {
        if(selectedClass.equals("Class 1")) {
            subjectList.clear();
            subjectList.add("Maths");
            subjectList.add("Science");
            subjectList.add("English");
        } else if(selectedClass.equals("Class 2")) {
            subjectList.clear();
            subjectList.add("History");
            subjectList.add("Geography");
            subjectList.add("Civics");
            } else if(selectedClass.equals("Class 3")) {
            subjectList.clear();
            subjectList.add("Economics");
            subjectList.add("Accountancy");
            subjectList.add("Business Studies");
            }
   }
   
   public void save() {
        // Code to save data to MySQL database
        
        Student12 student = new Student12();
        student.setName(name);
        student.setAddress(address);
        student.setStudentClass(selectedClass);
        student.setSubjects(selectedSubjects);
        em.persist(student);
        
    }
   
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getAddress(){
        return address;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public String getSelectedclass(){
        return selectedClass;
    }
    public void setSelectedclass(String selectedClass){
        this.selectedClass = selectedClass;
    }
    public List<String> getSelectedsubjects(){
        return selectedSubjects;
    }
    public void setSelectedsubjects(List<String> selectedSubjects){
        this.selectedSubjects = selectedSubjects;
    }
    
    public List<String> getClasslist(){
        return classList;
    }
    public void setClassList(List<String> classList){
        this.classList = classList;
    }
    public List<String> getSubjectlist(){
        return subjectList;
    }
    public void setSubjectlist(List<String> subjectList){
        this.subjectList = subjectList;
    }

    /**
     * Creates a new instance of studentBean
     */
    
    
}
