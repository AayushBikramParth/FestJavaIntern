/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chillyfacts.com.category;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author aayush jha
 */
@Entity
@Table(catalog = "sql_demo", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Student12.findAll", query = "SELECT s FROM Student12 s"),
    @NamedQuery(name = "Student12.findByStudentId", query = "SELECT s FROM Student12 s WHERE s.studentId = :studentId"),
    @NamedQuery(name = "Student12.findByStudentName", query = "SELECT s FROM Student12 s WHERE s.studentName = :studentName"),
    @NamedQuery(name = "Student12.findByStudentEmail", query = "SELECT s FROM Student12 s WHERE s.studentEmail = :studentEmail"),
    @NamedQuery(name = "Student12.findByStudentPassword", query = "SELECT s FROM Student12 s WHERE s.studentPassword = :studentPassword"),
    @NamedQuery(name = "Student12.findByStudentGender", query = "SELECT s FROM Student12 s WHERE s.studentGender = :studentGender"),
    @NamedQuery(name = "Student12.findByStudentAddress", query = "SELECT s FROM Student12 s WHERE s.studentAddress = :studentAddress")})
public class Student12 implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "student_id", nullable = false)
    private Integer studentId;
    @Size(max = 100)
    @Column(name = "student_name", length = 100)
    private String studentName;
    @Size(max = 50)
    @Column(name = "student_email", length = 50)
    private String studentEmail;
    @Size(max = 20)
    @Column(name = "student_password", length = 20)
    private String studentPassword;
    @Size(max = 1)
    @Column(name = "student_gender", length = 1)
    private String studentGender;
    @Size(max = 100)
    @Column(name = "student_address", length = 100)
    private String studentAddress;

    public Student12() {
    }

    public Student12(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentPassword() {
        return studentPassword;
    }

    public void setStudentPassword(String studentPassword) {
        this.studentPassword = studentPassword;
    }

    public String getStudentGender() {
        return studentGender;
    }

    public void setStudentGender(String studentGender) {
        this.studentGender = studentGender;
    }

    public String getStudentAddress() {
        return studentAddress;
    }

    public void setStudentAddress(String studentAddress) {
        this.studentAddress = studentAddress;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (studentId != null ? studentId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Student12)) {
            return false;
        }
        Student12 other = (Student12) object;
        if ((this.studentId == null && other.studentId != null) || (this.studentId != null && !this.studentId.equals(other.studentId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.chillyfacts.com.category.Student12[ studentId=" + studentId + " ]";
    }

    void setName(String name) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setAddress(String address) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setStudentClass(String selectedClass) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setSubjects(List<String> selectedSubjects) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
