/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chillyfacts.com.category;

import java.io.Serializable;
import java.util.List;
import javax.annotation.ManagedBean;
import javax.enterprise.context.SessionScoped;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author aayush jha
 */
@Entity
@Table(name = "Student12")
@ManagedBean
@SessionScoped
public class Student implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "student_name")
     private String student_name;
    
    @Column(name = "student_address")
    private String student_address;
    
     @Column(name = "student_class")
    private String student_class;
     
     @ElementCollection
    @CollectionTable(name = "student_subjects")
    @Column(name = "subject")
    private List<String> subject;

    
    

    public Long getId() {
        return id;
    }
    public void setId(Long id){
        this.id = id;
    }
    
      public String getStudent_name() {
        return student_name;
    }

    public void setStudent_name(String student_name) {
        this.student_name = student_name;
    }
    
    public String getStudent_address(){
        return student_address;
    }
    
    public void setStudent_address(String student_address){
        this.student_address = student_address;
    }
    
    public String getStudent_class(){
        return student_class;
    }
    
    public void setStudent_class(String student_class){
        this.student_class = student_class;
    }
    
    public List<String> getSubject(){
        return subject;
    }
    
    public void setSubject(List<String> subject){
        this.subject = subject;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Student)) {
            return false;
        }
        Student other = (Student) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.chillyfacts.com.category.Student[ id=" + id + " ]";
    }
    
}
